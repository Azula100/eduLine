module.exports = [
(()=>{"use strict";return[
"[project]/app/api/home/route.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$surgalt$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/surgalt.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$course$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/course.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$teachers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/teachers.js [app-route] (ecmascript)");
;
;
;
async function GET() {
    const out = {
        surgalt: [],
        classes: [],
        teachers: []
    };
    try {
        out.surgalt = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$surgalt$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listSurgalt"])({
            onlyActive: true
        });
    } catch (e) {
        console.error("HOME surgalt:", e);
        out.surgaltError = e.message;
    }
    try {
        out.classes = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$course$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listActiveCourses"])();
    } catch (e) {
        console.error("HOME course:", e);
        out.classesError = e.message;
    }
    try {
        out.teachers = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$teachers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listTeachers"])({
            onlyActive: true
        });
    } catch (e) {
        console.error("HOME teachers:", e);
        out.teachersError = e.message;
    }
    return Response.json(out);
}
}),
"[project]/lib/course.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ACTIVE",
    ()=>ACTIVE,
    "INACTIVE",
    ()=>INACTIVE,
    "addCourse",
    ()=>addCourse,
    "checkCourse",
    ()=>checkCourse,
    "cleanCourse",
    ()=>cleanCourse,
    "delCourse",
    ()=>delCourse,
    "editCourse",
    ()=>editCourse,
    "listActiveCourses",
    ()=>listActiveCourses,
    "listCourse",
    ()=>listCourse,
    "setCourseStatus",
    ()=>setCourseStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/db.js [app-route] (ecmascript)");
;
const ACTIVE = 1;
const INACTIVE = 0;
const SELECT = `
  SELECT c.courseID, c.surgaltID, s.surgaltNer,
         c.courseName, c.courseDetails, c.price,
         DATE_FORMAT(c.startDate,  '%Y-%m-%d') AS startDate,
         DATE_FORMAT(c.finishDate, '%Y-%m-%d') AS finishDate,
         c.hugatsaa, c.suudalToo, c.isStatus AS status
  FROM course c LEFT JOIN surgalt s ON s.surgaltID = c.surgaltID`;
async function listCourse({ onlyActive = false } = {}) {
    const [rows] = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].query(`${SELECT} ${onlyActive ? "WHERE c.isStatus = ?" : ""} ORDER BY c.courseID DESC`, onlyActive ? [
        ACTIVE
    ] : []);
    return rows;
}
async function addCourse(b) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].query(`INSERT INTO course
       (surgaltID, courseName, courseDetails, price, startDate, finishDate, hugatsaa, suudalToo, isStatus)
     VALUES (?,?,?,?,?,?,?,?,?)`, [
        b.surgaltID,
        b.courseName,
        b.courseDetails,
        b.price,
        b.startDate,
        b.finishDate,
        b.hugatsaa,
        b.suudalToo,
        ACTIVE
    ]);
}
async function editCourse(id, b) {
    const [r] = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].query(`UPDATE course SET surgaltID=?, courseName=?, courseDetails=?, price=?,
            startDate=?, finishDate=?, hugatsaa=?, suudalToo=?
     WHERE courseID=?`, [
        b.surgaltID,
        b.courseName,
        b.courseDetails,
        b.price,
        b.startDate,
        b.finishDate,
        b.hugatsaa,
        b.suudalToo,
        id
    ]);
    return r.affectedRows;
}
async function setCourseStatus(id, status) {
    if (![
        ACTIVE,
        INACTIVE
    ].includes(Number(status))) throw new Error("Төлөв буруу байна");
    const [r] = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].query("UPDATE course SET isStatus=? WHERE courseID=?", [
        Number(status),
        id
    ]);
    return r.affectedRows;
}
async function delCourse(id) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].query("DELETE FROM course WHERE courseID=?", [
        id
    ]);
}
function checkCourse(b) {
    if (!b.surgaltID) return "Сургалтаа сонгоно уу";
    if (!b.courseName?.trim()) return "Ангийн нэрийг оруулна уу";
    if (!b.startDate || !b.finishDate) return "Эхлэх, дуусах огноог оруулна уу";
    if (b.finishDate < b.startDate) return "Дуусах огноо эхлэхээс өмнө байж болохгүй";
    if (!(Number(b.price) >= 0) || b.price === "") return "Төлбөр буруу байна";
    if (!Number.isInteger(Number(b.suudalToo)) || Number(b.suudalToo) < 1) return "Суудлын тоо 1-ээс их бүхэл тоо байх ёстой";
    return null;
}
function cleanCourse(b) {
    return {
        surgaltID: Number(b.surgaltID),
        courseName: b.courseName.trim(),
        courseDetails: (b.courseDetails || "").trim(),
        price: Number(b.price),
        startDate: b.startDate,
        finishDate: b.finishDate,
        hugatsaa: (b.hugatsaa ?? "").toString().trim(),
        suudalToo: Number(b.suudalToo)
    };
}
async function listActiveCourses(surgaltID = null) {
    const [result] = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].query("CALL sp_active_courses(?)", [
        surgaltID
    ]);
    return result[0]; // CALL-ийн эхний result set
}
}),
"[project]/lib/db.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "db",
    ()=>db
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$mysql2$2f$promise$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/mysql2/promise.js [app-route] (ecmascript)");
;
const db = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$mysql2$2f$promise$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].createPool({
    host: process.env.DB_HOST,
    port: Number(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME
});
}),
"[project]/lib/surgalt.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addSurgalt",
    ()=>addSurgalt,
    "delSurgalt",
    ()=>delSurgalt,
    "editSurgalt",
    ()=>editSurgalt,
    "listSurgalt",
    ()=>listSurgalt
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/db.js [app-route] (ecmascript)");
;
// ↓↓↓ Workbench дээрх бодит нэрээр тааруулна (DESCRIBE surgalt) ↓↓↓
const T = "surgalt";
const ID = "surgaltID";
const NAME = "surgaltNer";
const DESC = "surgaltDetails";
async function listSurgalt() {
    const [rows] = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].query(`SELECT \`${ID}\` AS surgaltID, \`${NAME}\` AS surgaltNer, \`${DESC}\` AS surgaltDetails
     FROM \`${T}\` ORDER BY \`${ID}\` DESC`);
    return rows;
}
async function addSurgalt(p2, p3) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].query(`INSERT INTO \`${T}\` (\`${NAME}\`, \`${DESC}\`) VALUES (?, ?)`, [
        p2,
        p3
    ]);
}
async function editSurgalt(p1, p2, p3) {
    const [r] = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].query(`UPDATE \`${T}\` SET \`${NAME}\`=?, \`${DESC}\`=? WHERE \`${ID}\`=?`, [
        p2,
        p3,
        p1
    ]);
    return r.affectedRows;
}
async function delSurgalt(p1) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].query(`DELETE FROM \`${T}\` WHERE \`${ID}\`=?`, [
        p1
    ]);
}
}),
"[project]/lib/teachers.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addTeacher",
    ()=>addTeacher,
    "checkTeacher",
    ()=>checkTeacher,
    "delTeacher",
    ()=>delTeacher,
    "editTeacher",
    ()=>editTeacher,
    "listTeachers",
    ()=>listTeachers,
    "setTeacherActive",
    ()=>setTeacherActive
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bcryptjs$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/bcryptjs/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/db.js [app-route] (ecmascript)");
;
;
async function listTeachers({ onlyActive = false } = {}) {
    const [rows] = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].query(`SELECT userID, LName, FName, utas, userMail, subject, isActive AS status
     FROM users WHERE userStatus='T' ${onlyActive ? "AND isActive=1" : ""}
     ORDER BY LName, FName`);
    return rows;
}
function checkTeacher(b, isNew) {
    if (!b.lname?.trim() || !b.fname?.trim()) return "Овог, нэрийг оруулна уу";
    if (b.utas && !/^\d{8}$/.test(b.utas)) return "Утас 8 оронтой тоо байх ёстой";
    if (isNew) {
        if (!/^[А-ЯӨҮЁа-яөүё]{2}\d{8}$/.test(b.rd || "")) return "Регистр буруу (жишээ: АА12345678)";
        if (!b.email?.includes("@")) return "Имэйл буруу байна";
        if (!b.password || b.password.length < 6) return "Нууц үг хамгийн багадаа 6 тэмдэгт";
    }
    return null;
}
async function addTeacher(b, adminID) {
    const [dup] = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].query("SELECT 1 FROM users WHERE userMail=?", [
        b.email
    ]);
    if (dup.length) return "Энэ имэйл бүртгэлтэй байна";
    const hash = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bcryptjs$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].hash(b.password, 10);
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].query(`INSERT INTO users (LName, FName, RD, userMail, userPsw, sumID, utas, regDate, tokenCode, userStatus, subject, isActive)
     SELECT ?, ?, ?, ?, ?, sumID, ?, NOW(), '0', 'T', ?, 1 FROM users WHERE userID = ?`, [
        b.lname.trim(),
        b.fname.trim(),
        b.rd.toUpperCase(),
        b.email.trim(),
        hash,
        b.utas || null,
        (b.subject || "").trim(),
        adminID
    ]);
    return "OK";
}
async function editTeacher(id, b) {
    const [r] = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].query("UPDATE users SET LName=?, FName=?, utas=?, subject=? WHERE userID=? AND userStatus='T'", [
        b.lname.trim(),
        b.fname.trim(),
        b.utas || null,
        (b.subject || "").trim(),
        id
    ]);
    return r.affectedRows;
}
async function setTeacherActive(id, v) {
    const [r] = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].query("UPDATE users SET isActive=? WHERE userID=? AND userStatus='T'", [
        Number(v) ? 1 : 0,
        id
    ]);
    return r.affectedRows;
}
async function delTeacher(id) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].query("DELETE FROM users WHERE userID=? AND userStatus='T'", [
        id
    ]);
}
}),
]})(),
"[externals]/buffer [external] (buffer, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[externals]/net [external] (net, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("net", () => require("net"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/runtime-reacts.external.js [external] (next/dist/server/runtime-reacts.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/runtime-reacts.external.js", () => require("next/dist/server/runtime-reacts.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/node:diagnostics_channel [external] (node:diagnostics_channel, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("node:diagnostics_channel", () => require("node:diagnostics_channel"));

module.exports = mod;
}),
"[externals]/node:stream [external] (node:stream, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("node:stream", () => require("node:stream"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[externals]/process [external] (process, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("process", () => require("process"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/string_decoder [external] (string_decoder, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("string_decoder", () => require("string_decoder"));

module.exports = mod;
}),
"[externals]/timers [external] (timers, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("timers", () => require("timers"));

module.exports = mod;
}),
"[externals]/tls [external] (tls, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("tls", () => require("tls"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__21brrfymfxhp6._.js.map