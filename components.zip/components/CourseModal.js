import { useEffect, useState } from "react";

export default function CourseModal({
  isOpen,
  onClose,
  onSave,
  initialData = null,
  courses = [],
}) {
  const [form, setForm] = useState({
    courseId: "",
    name: "",
    isActive: true,
    regOpen: true,
    startDate: "",
    endDate: "",
    days: [],
    startTime: "18:00",
    endTime: "20:00",
    fee: "",
    seats: "",
    description: "",
  });

  useEffect(() => {
    if (initialData) {
      setForm({
        courseId: initialData.courseId ?? "",
        name: initialData.name ?? "",
        isActive: initialData.isActive ?? true,
        regOpen: initialData.regOpen === "N" ? false : Boolean(initialData.regOpen ?? true),
        startDate: initialData.startDate ?? "",
        endDate: initialData.endDate ?? "",
        days: initialData.days ?? [],
        startTime: initialData.startTime ?? "18:00",
        endTime: initialData.endTime ?? "20:00",
        fee: initialData.fee !== undefined && initialData.fee !== null ? String(initialData.fee) : "",
        seats: initialData.seats !== undefined && initialData.seats !== null ? String(initialData.seats) : "",
        description: initialData.description ?? "",
      });
    } else {
      setForm({
        courseId: "",
        name: "",
        isActive: true,
        regOpen: true,
        startDate: "",
        endDate: "",
        days: [],
        startTime: "18:00",
        endTime: "20:00",
        fee: "",
        seats: "",
        description: "",
      });
    }
  }, [initialData, isOpen]);

  if (!isOpen) return null;

  const toggleDay = (day) => {
    setForm((prev) => ({
      ...prev,
      days: prev.days.includes(day)
        ? prev.days.filter((d) => d !== day)
        : [...prev.days, day],
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await onSave({
      ...form,
      fee: form.fee === "" ? null : Number(String(form.fee).replaceAll(".", "").replaceAll(",", "")),
      seats: form.seats === "" ? 0 : Number(form.seats),
      regOpen: form.regOpen ? "Y" : "N",
    });
    onClose();
  };

  return (
    <div className="modal-backdrop">
      <div className="modal-card">
        <div className="modal-header">
          <h2>Анги удирдах</h2>
          <button type="button" onClick={onClose}>✕</button>
        </div>

        <form onSubmit={handleSubmit}>
          <label>СУРГАЛТ</label>
          <select
            value={form.courseId}
            onChange={(e) => setForm({ ...form, courseId: e.target.value })}
          >
            <option value="">Сонгох</option>
            {courses.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>

          <label>АНГИЙН НЭР</label>
          <input
            type="text"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
          />

          <div className="row">
            <div>
              <label>ТӨЛӨВ</label>
              <input
                type="checkbox"
                checked={form.isActive}
                onChange={(e) => setForm({ ...form, isActive: e.target.checked })}
              />
              <span>{form.isActive ? "Идэвхтэй" : "Идэвхгүй"}</span>
            </div>

            <div>
              <label>БҮРТГЭЛ</label>
              <input
                type="checkbox"
                checked={form.regOpen}
                onChange={(e) => setForm({ ...form, regOpen: e.target.checked })}
              />
              <span>{form.regOpen ? "Нээлттэй" : "Хаалттай"}</span>
            </div>
          </div>

          <div className="row">
            <div>
              <label>ЭХЛЭХ ОГНОО</label>
              <input
                type="date"
                value={form.startDate}
                onChange={(e) => setForm({ ...form, startDate: e.target.value })}
              />
            </div>
            <div>
              <label>ДУУСАХ ОГНОО</label>
              <input
                type="date"
                value={form.endDate}
                onChange={(e) => setForm({ ...form, endDate: e.target.value })}
              />
            </div>
          </div>

          <label>ХУВААРЬ</label>
          <div className="days-row">
            {["Да", "Мя", "Лх", "Пү", "Ба", "Бя", "Ня"].map((day) => (
              <button
                key={day}
                type="button"
                className={form.days.includes(day) ? "active" : ""}
                onClick={() => toggleDay(day)}
              >
                {day}
              </button>
            ))}
          </div>

          <div className="row">
            <div>
              <label>ТӨЛБӨР (₮)</label>
              <input
                type="text"
                inputMode="numeric"
                placeholder="Төлбөр оруулах"
                value={form.fee}
                onChange={(e) => setForm({ ...form, fee: e.target.value })}
              />
            </div>
            <div>
              <label>СУУДЛЫН ТОО</label>
              <input
                type="number"
                min="0"
                placeholder="0"
                value={form.seats}
                onChange={(e) => setForm({ ...form, seats: e.target.value })}
              />
            </div>
          </div>

          <label>ДЭЛГЭРЭНГҮЙ</label>
          <textarea
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
          />

          <button type="submit">Баталгаажуулах</button>
        </form>
      </div>
    </div>
  );
}