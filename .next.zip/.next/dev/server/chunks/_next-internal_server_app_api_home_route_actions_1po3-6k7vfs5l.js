module.exports = [
"[project]/.next-internal/server/app/api/home/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_home_route_actions_1po3-6k7vfs5l.js.map