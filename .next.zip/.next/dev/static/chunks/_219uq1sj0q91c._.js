(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_09s-p3o5amqg9._.css","static/chunks/_1d7wx_ea_r9lh._.js","static/chunks/components_HomeContent_0i_zfx_1w7ae4.js"],
    source: "entry"
});
